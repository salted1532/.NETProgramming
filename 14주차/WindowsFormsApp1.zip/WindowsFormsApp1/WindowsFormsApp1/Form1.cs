﻿using System;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        bool isopen = false;

        public Form1()
        {
            InitializeComponent();

            timer1.Interval = 50;
            timer1.Tick += timer1_Tick;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            if (isopen == true)
            {
                isopen = false;
            }
            else
            {
                isopen = true;
            }


        }

        private async void networkCheckQuiz()
        {
            string result = await Task.Run(() =>
            {
                string url = "http://58.145.23.13:5555/dotnet/app.do?kind=checkQuiz&quizId=0001&answer=김밥";
                string response = string.Empty;
                string data = "{datas~~~~}";

                // request setting
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Timeout = 10 * 1000;

                // Data Stream setting
                byte[] bytes = Encoding.ASCII.GetBytes(data);
                request.ContentLength = bytes.Length;

                using (Stream reqStream = request.GetRequestStream())
                {
                    reqStream.Write(bytes, 0, bytes.Length);
                }

                // POST Request & Response
                string responseText = string.Empty;
                using (HttpWebResponse res = (HttpWebResponse)request.GetResponse())
                {
                    HttpStatusCode status = res.StatusCode;
                    Stream response_stream = res.GetResponseStream();
                    using (StreamReader read_stream = new StreamReader(response_stream))
                    {
                        response = read_stream.ReadToEnd();
                    }
                }
                return response;
            });

            dynamic json = JObject.Parse(result);
            string isConfirm = json["isConfirm"];
            this.Invoke((MethodInvoker)(() =>
            {
                if (isConfirm.Equals("Y"))
                {
                    MessageBox.Show("정답");
                }
                else
                {
                    MessageBox.Show("오답");
                }
            }));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            if(isopen == true)
            {
                if (pictureBox1.Left < 500)
                {
                    pictureBox1.Left += 20;
                }
                else
                {
                    if (pictureBox1.Top < 150)
                    {
                        pictureBox1.Top += 20;
                    }
                }
            }
            if(isopen == false)
            {
                if (pictureBox1.Top > 50)
                {
                    pictureBox1.Top -= 20;
                }
                else
                {
                    if (pictureBox1.Left > 320)
                    {
                        pictureBox1.Left -= 20;
                    }
                }
            }


        }
    }
}
