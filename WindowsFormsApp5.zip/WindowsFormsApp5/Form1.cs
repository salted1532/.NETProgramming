﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Timo t = new Timo();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();

            var result = f.ShowDialog();
            if(result == DialogResult.OK)
            {
                textBox2.Text = f.result;
            }
        }
    }



    public class Champion
    {
        protected string name = "";
        protected int damage = 0;
        protected int speed = 0;

        public Champion()
        {

        }

        public void attack()
        {

        }

        public void move()
        {

        }
    }

    public class Garen : Champion
    {
        public Garen()
        {
            this.name = "가렌";
            this.damage = 200;
            this.speed = 5;
        }
    }

    public class Timo : Champion
    {
        public Timo()
        {
            this.name = "티모";
            this.damage = 100;
            this.speed = 7;
        }
    }
}
